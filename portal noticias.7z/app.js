var app = require('./config/server')();

//var db  = require('./config/mongo')();

const url = 'mongodb://leandro:leandro@ds141410.mlab.com:41410/db_leandro';
var db;

var mongo = require('mongodb');

db = mongo.connect(url, (err,database)=>{
	if(err) throw err;
	console.log(database);
})

//console.log(typeof connection);

var rotaNoticias = require('./app/routes/noticias')(app,db);
//rotaNoticias(app);

var rotaHome = require('./app/routes/home')(app);
//rotaHome(app)

var rotaForm = require('./app/routes/form_inclusao_noticias')(app);
//rotaForm(app)

app.listen(3000,()=>{
	console.log('Porta 3000 ok');
})