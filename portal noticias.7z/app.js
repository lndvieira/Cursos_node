var app = require('./config/server')();
//var mongoose = require('./config/mongoose')();

//var db  = require('./config/mongo')();


var rotaNoticias = require('./app/routes/noticias')(app);
//rotaNoticias(app);
var rotaHome = require('./app/routes/home')(app);
//rotaHome(app)

var rotaForm = require('./app/routes/form_inclusao_noticias')(app);
//rotaForm(app)


//console.log(typeof connection);

app.listen(3000,()=>{
	console.log('Porta 3000 ok');
})