var app = require('./config/server')();

var pages
//var db  = require('./config/mongo')();

const url = 'mongodb://leandro:leandro@ds141410.mlab.com:41410/db_leandro';
var db;

var mongo = require('mongodb');

db = mongo.connect(url, (err,database)=>{
	if(err) throw err;
	var db2 = database;

})

var rotaNoticias = require('./app/routes/noticias')(app);
//rotaNoticias(app);
var rotaHome = require('./app/routes/home')(app);
//rotaHome(app)

var rotaForm = require('./app/routes/form_inclusao_noticias')(app);
//rotaForm(app)

app.post('./app/routes/noticias',(req,res)=>{

	var data = {
		title: req.body.title, 
		text: req.body.text};
	
	db.collection('noticias').insertOne(data,(err,result)=>{
			
			if(err) throw err;
			
			console.log('Inserted to database');

			res.redirect('/');
	})
	
})


console.log('-----');
console.log(db);
console.log('fim db');
//console.log(typeof connection);



app.listen(3000,()=>{
	console.log('Porta 3000 ok');
})