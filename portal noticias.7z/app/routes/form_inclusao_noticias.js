module.exports = (app) => {
	app.get('/formulario_inclusao_noticia', (req,res)=>{
		console.log('veio aqui');
	var incluir = require('../../config/noticiasModel');
		console.log('aqui tambem');
		res.render('admin/form_add_noticia')
	})
}