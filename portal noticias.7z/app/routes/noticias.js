module.exports = (app,db)=>{
		this.db = db;
		this.app = app;
	app.get('/noticias', (req,res)=>{
		console.log('e')

		db.collection('noticias').find().toArray((err,result)=>{
			if(err) throw err;
		res.render('noticias/noticias', {noticias: result})
		})
	})
}