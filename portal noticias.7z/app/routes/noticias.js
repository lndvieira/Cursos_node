module.exports = (app)=>{
		this.app = app;
		var db = require('../../config/mongo')
	
	app.get('/noticias', (req,res)=>{
		console.log('e')

		//db.collection('noticias').find().toArray((err,result)=>{
		//	if(err) throw err;
		res.render('noticias/noticias')//, {noticias: result})
		//})
	})
}