module.export = ()=>{
		console.log('mongo.js');
		const url = 'mongodb://leandro:leandro@ds141410.mlab.com:41410/db_leandro';
		var mongo = require('mongodb');
		return mongo.connect(url, (err,database)=>{
			if(err) 
			throw err;
	});
}