module.exports = ()=>{
	
	const url = 'mongodb://leandro:leandro@ds141410.mlab.com:41410/db_leandro';
	var mongoose = require('mongoose');	
	mongoose.connect(url)

	var db =  mongoose.connection;

	db.on('error', console.error.bind(console, 'connection error:'));
	db.once('open', function(){
		//asdasdadasdasdasd
	})

}