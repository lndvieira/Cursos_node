module.exports = ()=>{
	console.log('server.js')
	var express = require ('express')
	var app = express();
	const bodyParser = require('body-parser');
	app.use(bodyParser.urlencoded({extended: true}));
	app.use(bodyParser.json()); //usado para que o servidor leia json
	app.use(express.static('public'));

	app.set('view engine', 'ejs');

	app.set('views', './app/views');
	return app
}
	//module.exports = app;
