	function(var mongoose = require('mongoose');

	var noticiasSchema = mongoose.Schema({
		Title: String,
		Text: String
	});		

	var noticiasInc = mongoose.model('noticiasInc', noticiasSchema);
	console.log('Veio ate aqui');
	module.exports = noticiasInc;
	)


	/// dar uma estudada nisso aqui

		//require is not a function