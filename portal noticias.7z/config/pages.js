module.exports = (app,db)=>{
	
this.app = app;
this.db = db;

var rotaNoticias = require('./routes/noticias')(app,db);
//rotaNoticias(app);
console.log('pages');
var rotaHome = require('./routes/home')(app);
//rotaHome(app)

var rotaForm = require('./routes/form_inclusao_noticias')(app);
//rotaForm(app)
}